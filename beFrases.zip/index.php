<?php
  // Silence is golden